#
# Regular cron jobs for the migasfree-client package
#
0 4	* * *	root	[ -x /usr/bin/migasfree-client_maintenance ] && /usr/bin/migasfree-client_maintenance
