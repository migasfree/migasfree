# Defaults for migasfree-client initscript
# sourced by /etc/init.d/migasfree-client
# installed at /etc/default/migasfree-client by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
