?package(migasfree-client):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="migasfree-client" command="/usr/bin/migasfree-client"
